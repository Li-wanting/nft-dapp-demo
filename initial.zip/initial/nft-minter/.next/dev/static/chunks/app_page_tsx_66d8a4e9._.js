(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_2598578f._.js",
  "static/chunks/node_modules_103c434a._.js"
],
    source: "dynamic"
});
